function code(){
    let code;
    code=document.getElementById("code").value;
    console.log(code);
    document.getElementById("try").innerHTML=code;
}